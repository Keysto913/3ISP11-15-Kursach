package com.example.happydog;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

import com.example.happydog.Adapter.CategoryAdapter;
import com.example.happydog.Models.Category;
import com.example.happydog.Models.User;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    ImageButton btnSignIn, btnReg;
    FirebaseAuth auth;
    FirebaseDatabase db;
    DatabaseReference users;
    private String USER_KEY = "User";

    RelativeLayout root;

    RecyclerView categoryRecycler;
    CategoryAdapter categoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSignIn = findViewById(R.id.btnSignIn);
        btnReg = findViewById(R.id.btnReg);

        root = findViewById(R.id.root_element);

        auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance();
        users = db.getReference("Users");


        btnReg.setOnClickListener(view -> showRegisterWindow());
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSignInListener();

            }
        });
    }

    private void showSignInListener(){
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Войти");
        dialog.setMessage("Введите данные для входа");
        LayoutInflater inflater = LayoutInflater.from(this);
        View activity_signin = inflater.inflate(R.layout.activity_signin, null);
        dialog.setView(activity_signin);

        final MaterialEditText email = activity_signin.findViewById(R.id.emailField);
        final MaterialEditText password = activity_signin.findViewById(R.id.passField);

        dialog.setNegativeButton("Отменить", (dialogInterface, which) -> dialogInterface.dismiss());
        // Проверка введенных данных
        dialog.setPositiveButton("Войти", (dialogInterface, which) -> {
            if (TextUtils.isEmpty(email.getText().toString())){
                Snackbar.make(root,"Введите вашу почту",Snackbar.LENGTH_SHORT).show();
                return;
            }
            if (password.getText().toString().length() < 5){
                Snackbar.make(root,"Введите пароль не менее 5 символов",Snackbar.LENGTH_SHORT).show();
                return;
            }
            auth.signInWithEmailAndPassword(email.getText().toString(),password.getText().toString())
                    .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            Snackbar.make(root,"Авторизация прошла успешно",Snackbar.LENGTH_LONG).show();
                            startActivity(new Intent(MainActivity.this,KatalogActivity.class));
                            finish();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Snackbar.make(root,"Ошибка авторизации. " + e.getMessage(), Snackbar.LENGTH_SHORT).show();
                        }
                    });
        });
        dialog.show();
    }
        //Диалоговое окно регстрации
    private void showRegisterWindow() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Зарегистрироваться");
        dialog.setMessage("Введите данные для регистрации");
        LayoutInflater inflater = LayoutInflater.from(this);
        View activity_register = inflater.inflate(R.layout.activity_register, null);
        dialog.setView(activity_register);

       final MaterialEditText email = activity_register.findViewById(R.id.emailField);
       final MaterialEditText phone = activity_register.findViewById(R.id.phoneField);
       final MaterialEditText password = activity_register.findViewById(R.id.passField);
       final MaterialEditText name = activity_register.findViewById(R.id.nameField);

        dialog.setNegativeButton("Отменить", (dialogInterface, which) -> dialogInterface.dismiss());
            // Проверка введенных данных
        dialog.setPositiveButton("Добваить", (dialogInterface, which) -> {
            if (TextUtils.isEmpty(email.getText().toString())){
                Snackbar.make(root,"Введите вашу почту",Snackbar.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(phone.getText().toString())){
                Snackbar.make(root,"Введите ваш номер",Snackbar.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(name.getText().toString())){
                Snackbar.make(root,"Введите ваше Имя",Snackbar.LENGTH_SHORT).show();
                return;
            }
            if (password.getText().toString().length() < 5){
                Snackbar.make(root,"Введите пароль не менее 5 символов",Snackbar.LENGTH_SHORT).show();
                return;
            }

            //Регистрация пользователя
            // ф-я вызывается если польз-ль успешно добавлен в базу
            auth.createUserWithEmailAndPassword(email.getText().toString(),password.getText().toString())
                    .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            User user = new User();
                            user.setEmail(email.getText().toString());
                            user.setName(name.getText().toString());
                            user.setPassword(password.getText().toString());
                            user.setPhone(phone.getText().toString());
                            users = FirebaseDatabase.getInstance().getReference(USER_KEY);
                            Snackbar.make(root,"Пользователь зарегистрирован",Snackbar.LENGTH_LONG).show();
                        }
                    });
        });
        dialog.show();
    }

}