package com.example.happydog;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class PurchaseActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase);
    }
    public void Thanksgiving(View view) {
        Toast toast = Toast.makeText(getApplicationContext(),
                "Заказ совершен успешно, спасибо за покупку", Toast.LENGTH_LONG);
        toast.show();
    }
}
