package com.example.happydog.Models;

import java.util.HashSet;
import java.util.Set;

public class Order { // список индентификтаров товаров добавленных в корзину
    public static Set<Integer> items_id = new HashSet<>();

}
