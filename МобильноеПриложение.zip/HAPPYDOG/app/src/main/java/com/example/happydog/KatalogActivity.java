package com.example.happydog;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.happydog.Adapter.CategoryAdapter;
import com.example.happydog.Adapter.CourseAdapter;
import com.example.happydog.Models.Category;
import com.example.happydog.Models.Course;

import java.util.ArrayList;
import java.util.List;

public class KatalogActivity extends AppCompatActivity {

    RecyclerView categoryRecycler, courseRecycler;
    CategoryAdapter categoryAdapter;
    static CourseAdapter courseAdapter;
    static List<Course> courseList = new ArrayList<>();
    static List<Course> fullCoursesList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_katalog);
        List<Category> categoryList = new ArrayList<>();
        categoryList.add(new Category(1,"Сухой корм"));
        categoryList.add(new Category(2,"Влажный корм"));

        setCategoryRecycler(categoryList);


        courseList.add(new Course(1,"zojcourse","Для проблем\nс желудком","2 мес","от 3 мес","#5E5858","Полнорационный диетический корм для кошек, " +
                "применяемый при пищевой аллергии или пищевой непереносимости некоторых ингредиентов. " +
                "Специально отобранные источники белков и углеводов. РЕКОМЕНДАЦИИ: Посоветуйтесь с вашим " +
                "ветеринарным врачом по поводу целесообразности использования данного корма. Курс применения сухого корма HYPOALLERGENIC — 3–8 недель",1));
        courseList.add(new Course(2,"bodgodcource","Насыщенный\nОмега3","1 мес","от 2 мес", "#C24242","Улучшает состояние кожи и шерстного покрова, " +
                "ускоряет и нормализует сезонную линьку, уменьшает проявление кожных заболеваний, " +
                "повышает эффективность дрессировки",1));
        courseList.add(new Course(3,"puppet","Для щенков\n","3 мес","от 1 меc","#5A8C4D","«5 слагаемых здоровья», " +
                "каждая рецептура учитывает особые потребности собаки с учетом ее возраста и особенностей размера породы. " +
                "ЗДОРОВЬЕ МОЧЕВЫДЕЛИТЕЛЬНОЙ СИСТЕМЫ - Специальная формуля для поддержания здоровья мочевыводительной системы ЖИЗНЕННАЯ ЭНЕРГИЯ" +
                " - Содержит повышенные уровни витаминов В1, В2, В6 и железа, способствующие поддержанию активности собаки",2));
        fullCoursesList.addAll(courseList); // всегда состоит из всех тех курсов добавленных в самом начале приложения
        setCourseRecycler (courseList);

    }

    public void openShoppingCart(View view){
    Intent intent = new Intent(this,OrderPageActivity.class);
    startActivity(intent);
    }

    private void setCourseRecycler(List<Course> courseList) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this,RecyclerView.HORIZONTAL,false);

        courseRecycler = findViewById(R.id.courseRecycler);
        courseRecycler.setLayoutManager(layoutManager);

        courseAdapter = new CourseAdapter(this, courseList);
        courseRecycler.setAdapter(courseAdapter);

    }

    private void setCategoryRecycler(List<Category> categoryList) {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this,RecyclerView.HORIZONTAL,false);

        categoryRecycler = findViewById(R.id.categoryRecycler);
        categoryRecycler.setLayoutManager(layoutManager);

        categoryAdapter = new CategoryAdapter(this, categoryList);
        categoryRecycler.setAdapter(categoryAdapter);
    }

    public static void showCoursesByCategory(int category) { //только те курсы которые должны быть видны пользователю
        courseList.clear();
        courseList.addAll(fullCoursesList); //спрева очистятся все курсы, потом добавятся все из fullCoursesList и далее фильтрация
        List<Course> filterCourses = new ArrayList<>();
                for (Course c : courseList) {
                    if (c.getCategory() == category)
                        filterCourses.add(c);// если категория объекта совпадает с той которая передается в кач параметре, то только тогда к filterCourses добавляем объект.
                }
                courseList.clear();
                courseList.addAll(filterCourses);
                courseAdapter.notifyDataSetChanged(); //обновляет RecyclerView
    }
}
